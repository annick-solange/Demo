import java.util.ArrayList;
import java.util.List;
public class ClasseA {
	private int b;
	private String type;
	
    public  ClasseA(int value) {
    	this.b = value;
	}

   public  ClasseA(int value, String name) {
	    this(value);
    	this.type = name;
	}
    public String toString() {
        return  "attribut: "  + type;
     }
    public int getB() {
        return  b;
     }
    public String getType() {
        return  type;
     }
    public void setType(String name) {
        this.type = name;
     }


}
