import java.util.ArrayList;
public class ClasseB {
	private ArrayList<ClasseB>ListeB=new ArrayList<ClasseB>();

	public ArrayList<ClasseB> getListeB() {
		return ListeB;
	}

	public void setListeA(ArrayList<ClasseB> listeB) {
		ListeB = listeB;
	}
	

}
