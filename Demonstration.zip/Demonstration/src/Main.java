import java.util.ArrayList;

public class Main {

	public static String findItemType(ArrayList<ClasseA> list, ClasseA item) {
		for (ClasseA element : list)  {
			if (item.getB() == element.getB()) {
				return element.getType();
			}
		}
		return "not found";
	}
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		ArrayList<ClasseA> list1 = new ArrayList<ClasseA>();
		list1.add(new ClasseA(1, "one"));
		list1.add(new ClasseA(2, "two"));
		list1.add(new ClasseA(3, "three"));
		list1.add(new ClasseA(4, "four"));
		list1.add(new ClasseA(5, "five"));
//		System.out.println(list1);
	    
		ArrayList<ClasseA> list2 = new ArrayList<ClasseA>();
		list2.add(new ClasseA(1));
		list2.add(new ClasseA(2));
		list2.add(new ClasseA(3));
		list2.add(new ClasseA(4));
		list2.add(new ClasseA(5));
		
		System.out.println("before" + list2);
		
		for( ClasseA item : list2 ) {
			item.setType(findItemType(list1, item));
		}
		System.out.println(list2);
	}
}
